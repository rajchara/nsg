<!-- BEGIN_TF_DOCS -->
## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_terraform"></a> [terraform](#requirement\_terraform) | >=1.9 |
| <a name="requirement_azurerm"></a> [azurerm](#requirement\_azurerm) | 4.14.0 |
| <a name="requirement_null"></a> [null](#requirement\_null) | >=3.1.0 |
| <a name="requirement_random"></a> [random](#requirement\_random) | 3.6.3 |
| <a name="requirement_tls"></a> [tls](#requirement\_tls) | 4.0.6 |

## Providers

| Name | Version |
|------|---------|
| <a name="provider_azurerm"></a> [azurerm](#provider\_azurerm) | 4.14.0 |
| <a name="provider_null"></a> [null](#provider\_null) | >=3.1.0 |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [azurerm_network_security_group.nsg](https://registry.terraform.io/providers/hashicorp/azurerm/4.14.0/docs/resources/network_security_group) | resource |
| [azurerm_network_security_rule.nsg_rule](https://registry.terraform.io/providers/hashicorp/azurerm/4.14.0/docs/resources/network_security_rule) | resource |
| [azurerm_subnet_network_security_group_association.existing_nsg_association](https://registry.terraform.io/providers/hashicorp/azurerm/4.14.0/docs/resources/subnet_network_security_group_association) | resource |
| [azurerm_subnet_network_security_group_association.subnet_nsg_association](https://registry.terraform.io/providers/hashicorp/azurerm/4.14.0/docs/resources/subnet_network_security_group_association) | resource |
| [null_resource.validate_no_existing_nsg](https://registry.terraform.io/providers/hashicorp/null/latest/docs/resources/resource) | resource |
| [azurerm_network_security_group.existing](https://registry.terraform.io/providers/hashicorp/azurerm/4.14.0/docs/data-sources/network_security_group) | data source |
| [azurerm_subnet.subnet](https://registry.terraform.io/providers/hashicorp/azurerm/4.14.0/docs/data-sources/subnet) | data source |
| [azurerm_virtual_network.existing_vnet](https://registry.terraform.io/providers/hashicorp/azurerm/4.14.0/docs/data-sources/virtual_network) | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_associate_nsg"></a> [associate\_nsg](#input\_associate\_nsg) | Whether to associate the NSG with the subnet. Set to false to skip association. | `bool` | `true` | no |
| <a name="input_context"></a> [context](#input\_context) | (Optional) The context that the resource is deployed in. e.g. devops, logs, lake | `string` | `"01"` | no |
| <a name="input_create_nsg"></a> [create\_nsg](#input\_create\_nsg) | Boolean to decide whether to create the NSG. Defaults to false. | `bool` | `false` | no |
| <a name="input_existing_nsg_name"></a> [existing\_nsg\_name](#input\_existing\_nsg\_name) | The name of the existing Network Security Group to use when create\_nsg is false. | `string` | `null` | no |
| <a name="input_location"></a> [location](#input\_location) | The Azure location for the NSG. | `string` | n/a | yes |
| <a name="input_lookup_subnet"></a> [lookup\_subnet](#input\_lookup\_subnet) | Whether to look up the subnet by name/VNet (true), or skip lookup and use subnet\_id directly (false). | `bool` | `true` | no |
| <a name="input_resource_group_name"></a> [resource\_group\_name](#input\_resource\_group\_name) | The name of the resource group where the NSG will be created or exists. | `string` | n/a | yes |
| <a name="input_rules"></a> [rules](#input\_rules) | Map of NSG rules with key as rule name and values as configuration. | <pre>map(object({<br>    priority                   = number<br>    direction                  = string<br>    access                     = string<br>    protocol                   = string<br>    source_port_range          = string<br>    destination_port_range     = string<br>    source_address_prefix      = string<br>    destination_address_prefix = string<br>  }))</pre> | n/a | yes |
| <a name="input_subnet_id"></a> [subnet\_id](#input\_subnet\_id) | If you already know the subnet id (e.g. created in this plan), set it here and skip the data lookup. | `string` | `null` | no |
| <a name="input_subnet_name"></a> [subnet\_name](#input\_subnet\_name) | Name of the subnet to associate with the NSG (when lookup\_subnet = true). | `string` | `null` | no |
| <a name="input_subnet_resource_group_name"></a> [subnet\_resource\_group\_name](#input\_subnet\_resource\_group\_name) | Resource group name where the VNet/subnet exists. Defaults to resource\_group\_name if null. | `string` | `null` | no |
| <a name="input_subscription_id"></a> [subscription\_id](#input\_subscription\_id) | The Azure subscription ID (GUID format). | `string` | n/a | yes |
| <a name="input_tags"></a> [tags](#input\_tags) | (Optional) A mapping of tags to assign to the NSG resources. | `map(string)` | `{}` | no |
| <a name="input_vnet_name"></a> [vnet\_name](#input\_vnet\_name) | Name of the virtual network containing the subnet (when lookup\_subnet = true). | `string` | `null` | no |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_existing_nsg_id"></a> [existing\_nsg\_id](#output\_existing\_nsg\_id) | The ID of the referenced existing NSG. |
| <a name="output_existing_subnet_nsg_id"></a> [existing\_subnet\_nsg\_id](#output\_existing\_subnet\_nsg\_id) | The ID of the existing NSG on the subnet (if any). |
| <a name="output_nsg_id"></a> [nsg\_id](#output\_nsg\_id) | The ID of the created NSG. |
| <a name="output_nsg_rule_ids"></a> [nsg\_rule\_ids](#output\_nsg\_rule\_ids) | The IDs of the created NSG rules. |
| <a name="output_subnet_has_existing_nsg"></a> [subnet\_has\_existing\_nsg](#output\_subnet\_has\_existing\_nsg) | Whether the target subnet already came with an NSG. |
| <a name="output_subnet_id"></a> [subnet\_id](#output\_subnet\_id) | The ID of the subnet associated with the NSG. |
| <a name="output_subnet_nsg_association_id"></a> [subnet\_nsg\_association\_id](#output\_subnet\_nsg\_association\_id) | The ID of the subnet NSG association. |
<!-- END_TF_DOCS -->