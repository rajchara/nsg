All notable changes to this project will be documented in this file.

Please use semantic versioning and follow this format:

[Date] : [version]: 
- [description]
- [description]

#####################################################################
[14-05-2025] : [V1.1.1]
- fixed null handling on local variable

[13-05-2025] : [V1.1.1]
- fix test main.tf
- fix variable validation rules not making logical sense

[13-05-2025] : [V1.1.0]
 - updated testing for Same resource group NSG and subnet and Cross resource group NSG and subnet
 - updated module to support cross RG subnet association
 
[17-01-2025] : [V1.0.0]
- initial creation